package com.example.moviecatalogue.dataSource.network;

public class Utils {

    public static ApiClient.ApiInterface geClient() {
        return ApiClient.getInterface();
    }
}
